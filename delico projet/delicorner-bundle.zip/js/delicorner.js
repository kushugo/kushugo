/* Délicorner — case study interactions
   Mirrors the logic pattern of gouvernement.js : IntersectionObserver reveal,
   TOC scroll-spy, lightbox, animated KPI counters, + the CX Copilot Slack-scene
   loop and the before/after comparison. Respects prefers-reduced-motion. */
(function () {
    'use strict';

    window.__deliReveal = true;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* footer year */
    var y = document.getElementById('year');
    if (y) y.textContent = new Date().getFullYear();

    /* ---------- Reveal séquencé (stagger façon Framer) ---------- */
    var sections = document.querySelectorAll('.content-section');

    function collectTargets(section) {
        var out = [];
        Array.prototype.forEach.call(section.children, function (child) {
            if (child.classList.contains('impact')) {
                child.querySelectorAll(':scope > .impact-hero, :scope > .impact-cols > .ic, :scope > .impact-foot').forEach(function (el) { out.push(el); });
            } else if (child.matches('.spec-grid, .method-grid, .stack-row')) {
                Array.prototype.forEach.call(child.children, function (el) { out.push(el); });
            } else {
                out.push(child);
            }
        });
        return out;
    }

    var groups = [];
    sections.forEach(function (s) {
        var targets = collectTargets(s);
        if (!reduced) targets.forEach(function (el) { el.classList.add('rv'); });
        groups.push({ section: s, targets: targets });
    });

    function reveal(group) {
        group.targets.forEach(function (el, i) {
            var d = Math.min(i, 9) * 70;
            el.style.transitionDelay = d + 'ms';
            el.classList.add('in');
            setTimeout(function () { el.classList.remove('rv', 'in'); el.style.transitionDelay = ''; }, d + 850);
        });
        group.section.classList.add('visible');
    }

    if (reduced || !('IntersectionObserver' in window)) {
        groups.forEach(reveal);
    } else {
        var revealIO = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var g = groups.filter(function (x) { return x.section === entry.target; })[0];
                    if (g) reveal(g);
                    revealIO.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -90px 0px' });
        groups.forEach(function (g) { revealIO.observe(g.section); });
    }

    /* ---------- Parallax léger sur le visuel hero ---------- */
    if (!reduced) {
        var heroImg = document.querySelector('.hero-image img');
        if (heroImg) {
            var ticking = false;
            var onParallax = function () {
                if (ticking) return;
                ticking = true;
                requestAnimationFrame(function () {
                    var sy = window.pageYOffset;
                    if (sy < 800) heroImg.style.transform = 'translateY(' + (sy * 0.08).toFixed(1) + 'px)';
                    ticking = false;
                });
            };
            window.addEventListener('scroll', onParallax, { passive: true });
        }
    }

    /* ---------- Barre de progression de lecture ---------- */
    var progress = document.querySelector('.scroll-progress');
    if (progress) {
        var pTick = false;
        var onProgress = function () {
            if (pTick) return;
            pTick = true;
            requestAnimationFrame(function () {
                var h = document.documentElement;
                var max = h.scrollHeight - h.clientHeight;
                progress.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
                pTick = false;
            });
        };
        window.addEventListener('scroll', onProgress, { passive: true });
        onProgress();
    }

    /* ---------- TOC : click + scroll-spy ---------- */
    var tocItems = document.querySelectorAll('.toc-item');
    tocItems.forEach(function (item) {
        item.addEventListener('click', function () {
            var section = document.getElementById(item.dataset.section);
            if (!section) return;
            var offset = section.getBoundingClientRect().top + window.pageYOffset - 100;
            window.scrollTo({ top: offset, behavior: 'smooth' });
        });
    });
    var spyTargets = [];
    tocItems.forEach(function (item) {
        var s = document.getElementById(item.dataset.section);
        if (s) spyTargets.push(s);
    });
    function onScrollSpy() {
        var current = '';
        spyTargets.forEach(function (s) {
            if (window.pageYOffset >= s.offsetTop - 200) current = s.id;
        });
        tocItems.forEach(function (item) {
            item.classList.toggle('active', item.dataset.section === current);
        });
    }
    window.addEventListener('scroll', onScrollSpy, { passive: true });
    onScrollSpy();

    /* ---------- Header shadow on scroll (fallback if nav.js absent) ---------- */
    var header = document.getElementById('header');
    if (header) {
        var onHdr = function () { header.classList.toggle('scrolled', window.pageYOffset > 20); };
        window.addEventListener('scroll', onHdr, { passive: true });
        onHdr();
    }

    /* ---------- Nav toggle (fallback) ---------- */
    var toggle = document.querySelector('.nav-toggle');
    if (toggle) {
        toggle.addEventListener('click', function () {
            var open = document.body.classList.toggle('is-nav-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        document.querySelectorAll('.nav-links a').forEach(function (a) {
            a.addEventListener('click', function () {
                document.body.classList.remove('is-nav-open');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });
    }

    /* ---------- Lightbox ---------- */
    var lightbox = (function () {
        var overlay = document.getElementById('lightboxOverlay');
        var image = document.getElementById('lightboxImage');
        var closeBtn = document.getElementById('lightboxClose');
        if (!overlay || !image) return { open: function () {} };
        function open(src, alt) {
            if (!src) return;
            image.src = src; image.alt = alt || '';
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        function close() {
            overlay.classList.remove('active');
            document.body.style.overflow = '';
            setTimeout(function () { image.src = ''; image.alt = ''; }, 220);
        }
        if (closeBtn) closeBtn.addEventListener('click', close);
        overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && overlay.classList.contains('active')) close();
        });
        return { open: open, close: close };
    })();

    /* hero zoom button → opens hero image */
    var zoomBtn = document.querySelector('.hero-zoom-button');
    var heroImg = document.querySelector('.hero-image.data-hero img');
    if (zoomBtn && heroImg) {
        zoomBtn.addEventListener('click', function () {
            lightbox.open(heroImg.currentSrc || heroImg.src, heroImg.alt);
        });
    }

    /* click-to-zoom on gallery images */
    document.querySelectorAll('figure.shot img').forEach(function (img) {
        img.addEventListener('click', function () {
            lightbox.open(img.currentSrc || img.src, img.alt);
        });
    });

    /* ---------- Interactive screen viewers (browser frame + tabs) ---------- */
    document.querySelectorAll('[data-viewer]').forEach(function (v) {
        var img = v.querySelector('.viewer-img');
        var cap = v.querySelector('.viewer-cap');
        var tabs = v.querySelectorAll('.v-tab');
        if (!img || !tabs.length) return;

        function setActive(tab) {
            tabs.forEach(function (t) { t.setAttribute('aria-selected', t === tab ? 'true' : 'false'); });
            var label = tab.textContent.trim();
            var src = tab.dataset.src;
            img.style.opacity = '0';
            var pre = new Image();
            pre.onload = function () { img.src = src; img.alt = label; img.style.opacity = '1'; };
            pre.onerror = function () { img.src = src; img.alt = label; img.style.opacity = '1'; };
            pre.src = src;
            if (cap) cap.textContent = label;
        }
        tabs.forEach(function (t) { t.addEventListener('click', function () { setActive(t); }); });

        var sel = v.querySelector('.v-tab[aria-selected="true"]') || tabs[0];
        if (sel && cap) cap.textContent = sel.textContent.trim();
        if (sel) img.alt = sel.textContent.trim();

        img.addEventListener('click', function () { lightbox.open(img.currentSrc || img.src, img.alt); });

        document.addEventListener('i18n:updated', function () {
            var cur = v.querySelector('.v-tab[aria-selected="true"]');
            if (cur) { if (cap) cap.textContent = cur.textContent.trim(); img.alt = cur.textContent.trim(); }
        });
    });

    /* ---------- Animated KPI counters ---------- */
    function decodeEntities(str) {
        var t = document.createElement('textarea');
        t.innerHTML = str;
        return t.value;
    }
    function animateCounter(el) {
        if (el.dataset.done) return;
        el.dataset.done = '1';
        var target = parseFloat(el.dataset.count || '0');
        var prefix = decodeEntities(el.dataset.prefix || '');
        var suffix = decodeEntities(el.dataset.suffix || '');
        if (reduced) { el.textContent = prefix + target + suffix; return; }
        var duration = 1200, start = performance.now();
        var ease = function (t) { return 1 - Math.pow(1 - t, 3); };
        (function tick(now) {
            var p = Math.min(1, (now - start) / duration);
            el.textContent = prefix + Math.round(target * ease(p)) + suffix;
            if (p < 1) { requestAnimationFrame(tick); }
            else { el.classList.add('num-pop'); setTimeout(function () { el.classList.remove('num-pop'); }, 600); }
        })(performance.now());
    }
    function watchCounters(scope) {
        var counters = scope.querySelectorAll('[data-count]');
        if (!counters.length) return;
        if (reduced || !('IntersectionObserver' in window)) {
            counters.forEach(animateCounter); return;
        }
        var cio = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) { animateCounter(entry.target); cio.unobserve(entry.target); }
            });
        }, { threshold: 0.4 });
        counters.forEach(function (c) { cio.observe(c); });
    }
    watchCounters(document);

    /* ---------- CX Copilot : Slack-scene choreography + interactive actions ---------- */
    var slackScene = document.querySelector('.slack-scene');
    if (slackScene) {
        var acts = slackScene.querySelectorAll('.sl-act');
        var panels = slackScene.querySelectorAll('.sl-panel');
        var replay = slackScene.querySelector('.sl-replay');
        var playing = false, timer = null;

        function cycle() {
            if (slackScene.classList.contains('is-acting')) return;
            slackScene.setAttribute('data-anim', 'off');
            void slackScene.offsetWidth; // reflow → restart CSS animations
            slackScene.setAttribute('data-anim', 'on');
        }
        function start() {
            if (reduced || playing || slackScene.classList.contains('is-acting')) return;
            playing = true; cycle(); timer = setInterval(cycle, 8000);
        }
        function stop() {
            playing = false;
            if (timer) { clearInterval(timer); timer = null; }
        }

        // Clic sur une action → joue le mock correspondant, met la boucle en pause
        function showPanel(name) {
            stop();
            slackScene.setAttribute('data-anim', 'on');      // garde l'intro visible
            slackScene.classList.add('is-acting');
            acts.forEach(function (b) { b.classList.toggle('is-active', b.dataset.act === name); });
            panels.forEach(function (p) {
                p.classList.remove('active');
                if (p.dataset.panel === name) { void p.offsetWidth; p.classList.add('active'); }
            });
        }
        acts.forEach(function (b) {
            b.addEventListener('click', function () { showPanel(b.dataset.act); });
        });
        if (replay) {
            replay.addEventListener('click', function () {
                slackScene.classList.remove('is-acting');
                acts.forEach(function (b) { b.classList.remove('is-active'); });
                panels.forEach(function (p) { p.classList.remove('active'); });
                if (reduced) { slackScene.setAttribute('data-anim', 'on'); }
                else { stop(); start(); }
            });
        }

        if (reduced) {
            slackScene.setAttribute('data-anim', 'on');
        } else if ('IntersectionObserver' in window) {
            var sio = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) start(); else stop();
                });
            }, { threshold: 0.35 });
            sio.observe(slackScene);
        } else {
            start();
        }
    }

    /* ===================== MODE IMMERSIF ===================== */
    (function immersive() {
        var imm = document.getElementById('immersive');
        var toggle = document.getElementById('immToggle');
        if (!imm || !toggle) return;
        var vp = document.getElementById('immViewport');
        var panel = document.getElementById('immPanel');
        var backdrop = document.getElementById('immBackdrop');
        var boxes = Array.prototype.slice.call(imm.querySelectorAll('.imm-box'));
        var hint = document.getElementById('immHint');
        var elNum = document.getElementById('immStepNum');
        var elH = document.getElementById('immH');
        var elBody = document.getElementById('immBody');
        var elFig = document.getElementById('immFig');
        var elPrev = document.getElementById('immPrev');
        var elNext = document.getElementById('immNext');
        var elDots = document.getElementById('immDots');
        var figs = {};
        [1, 2, 3, 4].forEach(function (n) { var im = document.getElementById('immFig' + n); figs[n] = im ? im.src : ''; });
        boxes.forEach(function (b) { b._closed = b.querySelector('img').getAttribute('src'); });
        var current = 0, open = false;

        function tr(key, fb) {
            if (window.__i18n && typeof window.__i18n.t === 'function') {
                var v = window.__i18n.t(key);
                if (v && v !== key) return v;
            }
            return fb;
        }

        for (var i = 1; i <= 4; i++) { elDots.appendChild(document.createElement('i')); }
        var dots = elDots.querySelectorAll('i');

        function renderStep() {
            elNum.textContent = tr('deli.imm.step', 'Étape') + ' ' + current + ' / 4';
            elH.textContent = tr('deli.imm.s' + current + '.t', 'Étape ' + current);
            elBody.innerHTML = tr('deli.imm.s' + current + '.b', '');
            elFig.src = figs[current]; elFig.alt = elH.textContent;
            elPrev.disabled = current <= 1; elNext.disabled = current >= 4;
            dots.forEach(function (dot, k) { dot.classList.toggle('on', k === current - 1); });
        }

        function openStep(n) {
            current = n;
            boxes.forEach(function (b) {
                var on = +b.dataset.step === n;
                b.classList.toggle('opened', on);
                b.querySelector('img').src = on ? b.dataset.open : b._closed;
            });
            renderStep();
            backdrop.classList.add('show');
            panel.classList.add('open');
            hideHint();
        }
        function clickBox(box) {
            var n = +box.dataset.step;
            var go = function () { if (n === 1) openChapter(); else if (n === 2 && window.__ch2) window.__ch2.open(); else if (n === 3 && window.__ch3) window.__ch3.open(); else openStep(n); };
            if (reduced) { go(); return; }
            box.classList.add('opening');
            setTimeout(function () { box.querySelector('img').src = box.dataset.open; box.classList.add('opened'); }, 290);
            setTimeout(function () { box.classList.remove('opening'); go(); }, 560);
        }
        function closePanel() {
            panel.classList.remove('open');
            backdrop.classList.remove('show');
            boxes.forEach(function (b) { b.classList.remove('opened', 'opening'); b.querySelector('img').src = b._closed; });
        }
        function hideHint() { if (hint) hint.classList.add('hide'); }

        /* ---- Étape 1 : chapitre scrollytelling ---- */
        var chap = document.getElementById('immChapter');
        var chapScroll = document.getElementById('chapScroll');
        var chapProgress = document.getElementById('chapProgress');
        var revealEls = chap ? Array.prototype.slice.call(chap.querySelectorAll('.r')) : [];
        var paraEls = chap ? Array.prototype.slice.call(chap.querySelectorAll('.chap-parallax')) : [];
        var paraTick = false;
        var numbersDone = false;
        var io = null;

        function chapToast(msg) {
            var t = document.createElement('div'); t.className = 'chap-toast'; t.textContent = msg;
            chap.appendChild(t);
            requestAnimationFrame(function () { t.classList.add('show'); });
            setTimeout(function () { t.classList.remove('show'); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 450); }, 2600);
        }
        function countUp(el) {
            var target = +el.dataset.count; if (el._done) return; el._done = true;
            if (reduced) { el.textContent = target.toLocaleString('fr-FR'); return; }
            var dur = 1100, t0 = null;
            function step(ts) {
                if (!t0) t0 = ts;
                var p = Math.min(1, (ts - t0) / dur);
                var e = 1 - Math.pow(1 - p, 3);
                el.textContent = Math.round(target * e).toLocaleString('fr-FR');
                if (p < 1) requestAnimationFrame(step); else el.textContent = target.toLocaleString('fr-FR');
            }
            requestAnimationFrame(step);
        }
        function onProgress() {
            if (!chapProgress) return;
            var max = chapScroll.scrollHeight - chapScroll.clientHeight;
            chapProgress.style.width = (max > 0 ? (chapScroll.scrollTop / max) * 100 : 0) + '%';
        }
        function onParallax() {
            if (reduced || !paraEls.length) return;
            var vh = chapScroll.clientHeight, top = chapScroll.getBoundingClientRect().top;
            paraEls.forEach(function (el) {
                var r = el.getBoundingClientRect();
                var center = (r.top - top) + r.height / 2 - vh / 2;
                var ty = Math.max(-44, Math.min(44, center * -0.06));
                el.style.transform = 'translateY(' + ty.toFixed(1) + 'px)';
            });
        }
        function onScroll() {
            onProgress();
            if (!paraTick) { paraTick = true; requestAnimationFrame(function () { onParallax(); board117Progress(); paraTick = false; }); }
        }
        /* ---- 117 → système (board piloté au scroll) ---- */
        var board = document.getElementById('board117');
        var b117tiles = [], b117grid = [], b117chaos = [], b117built = false;
        var b117pal = ['#5FA45A', '#E3C84A', '#1f5a32', '#C0492B', '#9ec98f', '#3b6ea5', '#cfe3c6', '#3a5e46'];
        function buildBoard() {
            if (!board || b117built) return;
            var bw = board.clientWidth, bh = board.clientHeight;
            if (bw < 10 || bh < 10) return;
            var COLS = 13, ROWS = 9, N = 117;
            var cw = bw / COLS, ch = bh / ROWS, tw = Math.max(6, cw * 0.74), th = Math.max(6, ch * 0.74);
            for (var i = 0; i < N; i++) {
                var t = document.createElement('div'); t.className = 'tile';
                t.style.width = tw.toFixed(1) + 'px'; t.style.height = th.toFixed(1) + 'px';
                t.style.backgroundColor = b117pal[i % b117pal.length];
                board.appendChild(t); b117tiles.push(t);
                var r = Math.floor(i / COLS), c = i % COLS;
                b117grid.push({ x: c * cw + (cw - tw) / 2, y: r * ch + (ch - th) / 2 });
                b117chaos.push({ x: Math.random() * (bw - tw), y: Math.random() * (bh - th), rot: Math.random() * 70 - 35 });
            }
            b117built = true;
        }
        function layoutBoard(p) {
            if (!b117tiles.length) return;
            var e = p < 0 ? 0 : p > 1 ? 1 : p, n = b117tiles.length;
            for (var i = 0; i < n; i++) {
                var a = b117chaos[i], b = b117grid[i];
                var local = Math.min(1, Math.max(0, (e - (i / n) * 0.3) / 0.7));
                local = 1 - Math.pow(1 - local, 3);
                var x = a.x + (b.x - a.x) * local, y = a.y + (b.y - a.y) * local, rot = a.rot * (1 - local);
                b117tiles[i].style.transform = 'translate(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px) rotate(' + rot.toFixed(1) + 'deg)';
            }
            var idx = e > 0.72 ? 2 : (e > 0.34 ? 1 : 0);
            chap.querySelectorAll('.b117-step').forEach(function (s) { s.classList.toggle('on', +s.dataset.step <= idx); });
        }
        function board117Progress() {
            if (!board || !b117built) return;
            var sec = board.closest('.beat-117'); if (!sec) return;
            var h = sec.offsetHeight - chapScroll.clientHeight;
            var p = h > 0 ? (chapScroll.scrollTop - sec.offsetTop) / h : 0;
            board.classList.remove('snap');
            layoutBoard(p);
        }

        /* ---- token → composant ---- */
        var tokPrev = document.getElementById('tokPreview');
        function resetTok() {
            if (!tokPrev) return;
            tokPrev.style.setProperty('--demo-color', '#0D2818');
            tokPrev.style.setProperty('--demo-radius', '14px');
            tokPrev.style.setProperty('--demo-space', '0px');
            chap.querySelectorAll('.tok-sw,.tok-opt').forEach(function (o) {
                var def = (o.dataset.val === '#0D2818' || o.dataset.val === '14px' || o.dataset.val === '0px');
                o.classList.toggle('on', def);
            });
        }

        /* ---- OKLCH ---- */
        var oklPlay = document.getElementById('oklPlay'), oklRot = document.getElementById('oklRot'),
            oklHandle = document.getElementById('oklHandle'), oklRing = document.getElementById('oklRing'),
            oklTag = document.getElementById('oklTag'), oklVal = document.getElementById('oklVal'),
            oklHex = document.getElementById('oklHex');
        var oklHue = 165, BRAND_H = 141.7;
        function oklRender() {
            if (!oklPlay) return;
            var h = oklHue;
            var snapped = Math.abs(((h - 286 + 540) % 360) - 180) < 7; // within ±7° of 286
            var L = snapped ? 0.556 : 0.62, C = snapped ? 0.258 : 0.17, H = snapped ? 286.1 : h;
            oklPlay.style.setProperty('--okL', L.toFixed(3));
            oklPlay.style.setProperty('--okC', C.toFixed(3));
            oklPlay.style.setProperty('--okH', H.toFixed(1));
            if (oklRot) oklRot.style.transform = 'rotate(' + h + 'deg)';
            if (oklHandle) oklHandle.setAttribute('aria-valuenow', Math.round(h));
            if (oklHex) oklHex.textContent = snapped ? '#7242FF' : 'oklch(' + L.toFixed(2) + ' ' + C.toFixed(2) + ' ' + Math.round(h) + ')';
            var dh = Math.abs(((h - BRAND_H + 540) % 360) - 180); // angular distance to brand
            if (oklVal) oklVal.textContent = 'ΔH ' + Math.round(dh) + '°';
            var good = dh > 90;
            oklTag.classList.toggle('good', good); oklTag.classList.toggle('bad', !good);
            oklTag.textContent = good ? tr('deli.imm.ch.okl.good', 'Résolu : succès distinct') : tr('deli.imm.ch.okl.bad', 'Conflit : succès dans le vert');
        }
        function oklSetHue(h) { oklHue = ((h % 360) + 360) % 360; oklRender(); }
        function oklReset() { oklSetHue(165); }
        function oklAngleFromEvent(e) {
            var r = oklRing.getBoundingClientRect();
            var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
            var p = (e.touches && e.touches[0]) ? e.touches[0] : e;
            return (Math.atan2(p.clientY - cy, p.clientX - cx) * 180 / Math.PI + 90 + 360) % 360;
        }

        // mini-jeu de flux token → composant
        var stackPipe = document.getElementById('stackPipe');
        var spColor = document.getElementById('spColor');
        var spRadius = document.getElementById('spRadius');
        var spPellet = document.getElementById('spPellet');
        var spTrack = document.getElementById('spTrack');
        var spTimers = [];
        function spClearTimers() { spTimers.forEach(clearTimeout); spTimers = []; }
        function spNodes() { return Array.prototype.slice.call(stackPipe.querySelectorAll('.sp-node')); }
        function spApply() {
            if (!stackPipe) return;
            var c = spColor.value, rad = +spRadius.value;
            stackPipe.style.setProperty('--sp-source', c);
            stackPipe.style.setProperty('--sp-primary', c);
            stackPipe.style.setProperty('--sp-radius', rad + 'px');
            stackPipe.style.setProperty('--sp-dotr', Math.min(rad, 9) + 'px');
            var v0 = document.getElementById('spV0'); if (v0) v0.textContent = c;
            var ro = document.getElementById('spRadiusOut'); if (ro) ro.textContent = rad + 'px';
        }
        function spRun() {
            if (!stackPipe) return;
            spApply(); spClearTimers();
            var nodes = spNodes();
            nodes.forEach(function (n) { n.classList.remove('lit', 'pop'); });
            if (reduced || !spPellet || !spTrack) { nodes.forEach(function (n) { n.classList.add('lit'); }); return; }
            var tr = spTrack.getBoundingClientRect();
            var xs = nodes.map(function (n) { var r = n.getBoundingClientRect(); return r.left - tr.left + r.width / 2; });
            spPellet.style.transition = 'none';
            spPellet.style.left = xs[0] + 'px';
            spPellet.classList.add('go');
            void spPellet.offsetWidth;
            spPellet.style.transition = '';
            nodes[0].classList.add('lit');
            [1, 2, 3].forEach(function (i) {
                spTimers.push(setTimeout(function () { spPellet.style.left = xs[i] + 'px'; }, (i - 1) * 470 + 60));
                spTimers.push(setTimeout(function () {
                    nodes[i].classList.add('lit');
                    if (i === 3) nodes[3].classList.add('pop');
                }, (i - 1) * 470 + 480));
            });
            spTimers.push(setTimeout(function () { spPellet.classList.remove('go'); }, 1900));
        }
        function resetPipe() {
            if (!stackPipe) return;
            spClearTimers();
            spColor.value = '#00806a'; spRadius.value = 10;
            spApply();
            spNodes().forEach(function (n) { n.classList.remove('lit', 'pop'); });
            if (spPellet) spPellet.classList.remove('go');
        }

        function openChapter() {
            if (!chap) return;
            chap.hidden = false;
            chapScroll.scrollTop = 0;
            onProgress();
            // reset reveals
            revealEls.forEach(function (el) { if (!el.classList.contains('chap-step')) el.classList.remove('in'); });
            chap.querySelectorAll('.chap-note.open').forEach(function (n) { n.classList.remove('open'); });
            chap.querySelectorAll('.chap-more[aria-expanded="true"]').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
            chap.querySelectorAll('[data-count]').forEach(function (el) { el._done = false; el.textContent = '0'; });
            chap.querySelectorAll('.chap-pin.open').forEach(function (p) { p.classList.remove('open'); });
            chap.querySelectorAll('.chap-mile[aria-expanded="true"]').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
            chap.querySelectorAll('.deliv-node').forEach(function (n) { n.classList.remove('on', 'hl'); });
            resetTok();
            oklReset();
            resetPipe();
            chap.querySelectorAll('.synth-tab').forEach(function (o, i) { o.classList.toggle('on', i === 0); });
            chap.querySelectorAll('.synth-list').forEach(function (o) { o.classList.toggle('on', o.id === 't0'); });
            requestAnimationFrame(function () { buildBoard(); layoutBoard(0); });
            // observe
            if (io) io.disconnect();
            if (reduced) {
                revealEls.forEach(function (el) { el.classList.add('in'); });
                chap.querySelectorAll('[data-count]').forEach(countUp);
            } else {
                io = new IntersectionObserver(function (entries) {
                    entries.forEach(function (en) {
                        if (en.isIntersecting) {
                            en.target.classList.add('in');
                            en.target.querySelectorAll && en.target.querySelectorAll('[data-count]').forEach(countUp);
                            if (en.target.dataset && en.target.dataset.count) countUp(en.target);
                            io.unobserve(en.target);
                        }
                    });
                }, { root: chapScroll, threshold: 0.25 });
                revealEls.forEach(function (el) { io.observe(el); });
            }
            var ex = document.getElementById('chapExit'); if (ex) ex.focus();
            requestAnimationFrame(onParallax);
        }
        function closeChapter() {
            if (chap) chap.hidden = true;
            if (io) io.disconnect();
            boxes.forEach(function (b) { b.classList.remove('opened', 'opening'); b.querySelector('img').src = b._closed; });
        }
        if (chap) {
            chapScroll.addEventListener('scroll', onScroll, { passive: true });
            document.getElementById('chapExit').addEventListener('click', closeChapter);
            document.getElementById('chapCta').addEventListener('click', function () { closeChapter(); if (window.__ch2) window.__ch2.open(); });
            chap.querySelectorAll('.chap-more').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    var note = document.getElementById(btn.dataset.note);
                    var openNow = note.classList.toggle('open');
                    btn.setAttribute('aria-expanded', openNow ? 'true' : 'false');
                });
            });
            var leaf = document.getElementById('chapLeaf');
            if (leaf) {
                var pop = function () { chapToast(tr('deli.imm.ch.leafToast', '🍃 Bien vu.')); };
                leaf.addEventListener('click', pop);
                leaf.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pop(); } });
            }

            // pins d'annotation
            var pins = Array.prototype.slice.call(chap.querySelectorAll('.chap-pin'));
            pins.forEach(function (p) {
                p.addEventListener('click', function (e) {
                    e.stopPropagation();
                    var wasOpen = p.classList.contains('open');
                    pins.forEach(function (o) { o.classList.remove('open'); });
                    if (!wasOpen) p.classList.add('open');
                });
            });
            chapScroll.addEventListener('click', function () { pins.forEach(function (o) { o.classList.remove('open'); }); }, true);

            // mini-jeu de flux
            if (stackPipe) {
                spColor.addEventListener('input', spApply);
                spRadius.addEventListener('input', spApply);
                spColor.addEventListener('change', spRun);
                spRadius.addEventListener('change', spRun);
                var runBtn = document.getElementById('spRun'); if (runBtn) runBtn.addEventListener('click', spRun);
                var ct = document.getElementById('spCodeToggle'), code = document.getElementById('spCode');
                if (ct && code) ct.addEventListener('click', function () { var o = code.classList.toggle('open'); ct.setAttribute('aria-expanded', o ? 'true' : 'false'); });
                spApply();
            }

            // frise des 14 jours + courbe de livraison liée
            var mileBtns = Array.prototype.slice.call(chap.querySelectorAll('.chap-mile'));
            var mileNodes = Array.prototype.slice.call(chap.querySelectorAll('.deliv-node'));
            function syncMileNodes() {
                mileBtns.forEach(function (b, i) { if (mileNodes[i]) mileNodes[i].classList.toggle('on', b.getAttribute('aria-expanded') === 'true'); });
            }
            mileBtns.forEach(function (m, i) {
                m.addEventListener('click', function () {
                    m.setAttribute('aria-expanded', m.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
                    syncMileNodes();
                });
                m.addEventListener('mouseenter', function () { if (mileNodes[i]) mileNodes[i].classList.add('hl'); });
                m.addEventListener('mouseleave', function () { if (mileNodes[i]) mileNodes[i].classList.remove('hl'); });
            });
            mileNodes.forEach(function (n, i) {
                n.addEventListener('click', function () {
                    if (mileBtns[i]) { mileBtns[i].click(); mileBtns[i].scrollIntoView({ block: 'nearest', behavior: reduced ? 'auto' : 'smooth' }); }
                });
            });

            // nav de sections
            var nav = document.getElementById('chapNav');
            var beats = Array.prototype.slice.call(chap.querySelectorAll('.chap-beat'));
            if (nav && beats.length) {
                beats.forEach(function (b, i) {
                    var btn = document.createElement('button');
                    btn.type = 'button';
                    btn.innerHTML = '<span class="lbl">' + (b.dataset.nav || (i + 1)) + '</span><span class="dotn"></span>';
                    btn.setAttribute('aria-label', b.dataset.nav || ('Section ' + (i + 1)));
                    btn.addEventListener('click', function () { b.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' }); });
                    nav.appendChild(btn);
                });
                var navBtns = nav.querySelectorAll('button');
                var navIO = new IntersectionObserver(function (ents) {
                    ents.forEach(function (en) {
                        if (en.isIntersecting) {
                            var idx = beats.indexOf(en.target);
                            navBtns.forEach(function (nb, k) { nb.classList.toggle('on', k === idx); });
                        }
                    });
                }, { root: chapScroll, rootMargin: '-45% 0px -45% 0px', threshold: 0 });
                beats.forEach(function (b) { navIO.observe(b); });
            }

            // token → composant
            if (tokPrev) {
                chap.querySelectorAll('.tok-sw, .tok-opt').forEach(function (b) {
                    b.addEventListener('click', function () {
                        var v = b.dataset.var;
                        chap.querySelectorAll('[data-var="' + v + '"]').forEach(function (o) { o.classList.remove('on'); });
                        b.classList.add('on');
                        tokPrev.style.setProperty(v, b.dataset.val);
                    });
                });
            }

            // OKLCH
            // OKLCH — cercle des teintes (drag / clic / clavier)
            if (oklRing && oklHandle) {
                var dragging = false;
                var onMove = function (e) { if (!dragging) return; e.preventDefault(); oklSetHue(oklAngleFromEvent(e)); };
                var stop = function () { dragging = false; };
                oklRing.addEventListener('pointerdown', function (e) { dragging = true; oklSetHue(oklAngleFromEvent(e)); });
                oklHandle.addEventListener('pointerdown', function (e) { dragging = true; e.stopPropagation(); });
                window.addEventListener('pointermove', onMove, { passive: false });
                window.addEventListener('pointerup', stop);
                oklHandle.addEventListener('keydown', function (e) {
                    var step = (e.key === 'ArrowRight' || e.key === 'ArrowUp') ? 5 : (e.key === 'ArrowLeft' || e.key === 'ArrowDown') ? -5 : 0;
                    if (step) { e.preventDefault(); oklSetHue(oklHue + step); }
                });
                oklReset();
            }

            // synthèse à onglets (test du prototype)
            chap.querySelectorAll('.synth-tab').forEach(function (tb) {
                tb.addEventListener('click', function () {
                    chap.querySelectorAll('.synth-tab').forEach(function (o) { o.classList.remove('on'); });
                    chap.querySelectorAll('.synth-list').forEach(function (o) { o.classList.remove('on'); });
                    tb.classList.add('on');
                    var t = document.getElementById(tb.dataset.tab); if (t) t.classList.add('on');
                });
            });

            // board : clic = ranger d'un coup
            if (board) {
                board.addEventListener('click', function () {
                    board.classList.add('snap');
                    layoutBoard(1);
                });
            }

            // curseur custom + profondeur souris (pointeur fin uniquement)
            var cursor = document.getElementById('chapCursor');
            var fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
            if (cursor && fine && !reduced) {
                var dTick = false, le = null;
                chap.addEventListener('pointermove', function (e) {
                    cursor.classList.add('show');
                    cursor.style.left = e.clientX + 'px'; cursor.style.top = e.clientY + 'px';
                    cursor.classList.toggle('hot', !!e.target.closest('button, a, input, [role="button"], [role="slider"], .tok-sw, .tok-opt, .chap-mile, .hue-ring, .ring-mark, .deliv-node'));
                    le = e;
                    if (!dTick) {
                        dTick = true;
                        requestAnimationFrame(function () {
                            var beat = le.target.closest ? le.target.closest('.chap-beat') : null;
                            if (beat) {
                                var cx = le.clientX / window.innerWidth - 0.5, cy = le.clientY / window.innerHeight - 0.5;
                                var g = beat.querySelector('.chap-ghost'); if (g) g.style.transform = 'translate(' + (cx * -26).toFixed(1) + 'px,' + (cy * -26).toFixed(1) + 'px)';
                                var bg = beat.querySelector('.chap-hero-bg'); if (bg) bg.style.transform = 'translate(' + (cx * 18).toFixed(1) + 'px,' + (cy * 18).toFixed(1) + 'px) scale(1.06)';
                            }
                            dTick = false;
                        });
                    }
                });
                chap.addEventListener('pointerleave', function () { cursor.classList.remove('show'); });
            }
        }

        function openImm() {
            imm.hidden = false;
            document.body.style.overflow = 'hidden';
            toggle.setAttribute('aria-pressed', 'true');
            vp.scrollLeft = 0;
            if (hint) hint.classList.remove('hide');
            imm.classList.remove('ready', 'intro');
            if (reduced) { imm.classList.add('ready'); }
            else {
                imm.classList.add('intro');
                setTimeout(function () { imm.classList.remove('intro'); imm.classList.add('ready'); }, 3500);
            }
            open = true;
            document.getElementById('immExit').focus();
        }
        function closeImm() {
            imm.hidden = true;
            document.body.style.overflow = '';
            imm.classList.remove('intro', 'ready');
            closePanel();
            if (chap) closeChapter();
            toggle.setAttribute('aria-pressed', 'false');
            open = false;
            toggle.focus();
        }

        toggle.addEventListener('click', function () { open ? closeImm() : openImm(); });
        document.getElementById('immExit').addEventListener('click', closeImm);
        document.getElementById('immPanelClose').addEventListener('click', closePanel);
        elPrev.addEventListener('click', function () { if (current > 1) openStep(current - 1); });
        elNext.addEventListener('click', function () { if (current < 4) openStep(current + 1); });
        boxes.forEach(function (b) { b.addEventListener('click', function () { clickBox(b); }); });
        backdrop.addEventListener('click', closePanel);

        var down = false, sx = 0, sl = 0;
        vp.addEventListener('pointerdown', function (e) {
            if (e.target.closest('.imm-box')) return;
            down = true; sx = e.clientX; sl = vp.scrollLeft;
            vp.classList.add('grabbing');
            try { vp.setPointerCapture(e.pointerId); } catch (err) {}
        });
        vp.addEventListener('pointermove', function (e) {
            if (!down) return;
            var dx = e.clientX - sx;
            if (Math.abs(dx) > 3) hideHint();
            vp.scrollLeft = sl - dx;
        });
        var endDrag = function () { down = false; vp.classList.remove('grabbing'); };
        vp.addEventListener('pointerup', endDrag);
        vp.addEventListener('pointercancel', endDrag);
        vp.addEventListener('wheel', function (e) {
            if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { vp.scrollLeft += e.deltaY; e.preventDefault(); hideHint(); }
        }, { passive: false });

        document.addEventListener('keydown', function (e) {
            if (!open) return;
            if (chap && !chap.hidden) {
                if (e.key === 'Escape') closeChapter();
                return;
            }
            if (e.key === 'Escape') { if (panel.classList.contains('open')) closePanel(); else closeImm(); }
            else if (e.key === 'ArrowRight') { if (panel.classList.contains('open') && current < 4) openStep(current + 1); else { vp.scrollLeft += 120; hideHint(); } }
            else if (e.key === 'ArrowLeft') { if (panel.classList.contains('open') && current > 1) openStep(current - 1); else { vp.scrollLeft -= 120; hideHint(); } }
            else if (e.key === 'Tab') {
                var f = Array.prototype.filter.call(imm.querySelectorAll('button:not([disabled])'), function (n) { return n.offsetParent !== null; });
                if (!f.length) return;
                var first = f[0], last = f[f.length - 1];
                if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
            }
        });

        document.addEventListener('i18n:updated', function () { if (open && panel.classList.contains('open')) renderStep();  });
    })();

})();

/* ---- Chapitre 2 : MVP fonctionnel (scrollytelling autonome) ---- */
(function () {
    var c2 = document.getElementById('immChapter2');
    if (!c2) return;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var sc = document.getElementById('chap2Scroll'),
        nav = document.getElementById('chap2Nav'),
        prog = document.getElementById('chap2Progress'),
        exit = document.getElementById('chap2Exit'),
        cta = document.getElementById('chap2Cta');
    var rev = Array.prototype.slice.call(c2.querySelectorAll('.r'));
    function countUp(el) {
        if (el._done) return; el._done = true;
        var target = +el.dataset.count || 0, pre = el.dataset.prefix || '', suf = el.dataset.suffix || '';
        if (reduced) { el.textContent = pre + target + suf; return; }
        var t0 = null, dur = 900;
        function step(ts) { t0 = t0 || ts; var p = Math.min(1, (ts - t0) / dur); el.textContent = pre + Math.round(target * (1 - Math.pow(1 - p, 3))) + suf; if (p < 1) requestAnimationFrame(step); }
        requestAnimationFrame(step);
    }
    function onProg() { if (!prog) return; var m = sc.scrollHeight - sc.clientHeight; prog.style.transform = 'scaleX(' + (m > 0 ? (sc.scrollTop / m) : 0) + ')'; }
    sc.addEventListener('scroll', onProg, { passive: true });
    var io;
    function open() {
        c2.hidden = false; sc.scrollTop = 0; onProg();
        rev.forEach(function (el) { el.classList.remove('in'); });
        c2.querySelectorAll('[data-count]').forEach(function (el) { el._done = false; el.textContent = '0'; });
        c2.querySelectorAll('.mvp-stat.flipped').forEach(function (s) { s.classList.remove('flipped'); s.setAttribute('aria-pressed', 'false'); });
        c2.querySelectorAll('.xfer-task').forEach(function (t) { t.classList.remove('in', 'scan'); });
        var _cl = document.getElementById('xferClaude'); if (_cl) _cl.classList.remove('active');
        var _fill = document.getElementById('xferFill'); if (_fill) _fill.style.width = '0';
        var _me = document.getElementById('mcpMe'); if (_me) _me.classList.remove('lit');
        var _lb = document.getElementById('mvpLb'); if (_lb) _lb.hidden = true;
        if (io) io.disconnect();
        if (reduced) {
            rev.forEach(function (el) { el.classList.add('in'); });
            c2.querySelectorAll('[data-count]').forEach(countUp);
        } else {
            io = new IntersectionObserver(function (es) {
                es.forEach(function (en) {
                    if (en.isIntersecting) {
                        en.target.classList.add('in');
                        if (en.target.querySelectorAll) en.target.querySelectorAll('[data-count]').forEach(countUp);
                        if (en.target.dataset && en.target.dataset.count) countUp(en.target);
                        if (en.target.id === 'mcpSplit') mcpPlay();
                        io.unobserve(en.target);
                    }
                });
            }, { root: sc, threshold: 0.25 });
            rev.forEach(function (el) { io.observe(el); });
        }
        if (exit) exit.focus();
    }
    function close() { c2.hidden = true; if (io) io.disconnect(); }
    if (exit) exit.addEventListener('click', close);
    if (cta) cta.addEventListener('click', close);
    document.addEventListener('keydown', function (e) {
        if (c2.hidden || e.key !== 'Escape') return;
        e.preventDefault();
        var _lb = document.getElementById('mvpLb');
        if (_lb && !_lb.hidden) { _lb.hidden = true; } else { close(); }
    });
    var beats = Array.prototype.slice.call(c2.querySelectorAll('.chap-beat'));
    if (nav && beats.length) {
        beats.forEach(function (b, i) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.innerHTML = '<span class="lbl">' + (b.dataset.nav || (i + 1)) + '</span><span class="dotn"></span>';
            btn.setAttribute('aria-label', b.dataset.nav || ('Section ' + (i + 1)));
            btn.addEventListener('click', function () { b.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' }); });
            nav.appendChild(btn);
        });
        var navBtns = nav.querySelectorAll('button');
        var nio = new IntersectionObserver(function (es) {
            es.forEach(function (en) { if (en.isIntersecting) { var idx = beats.indexOf(en.target); navBtns.forEach(function (x, j) { x.classList.toggle('on', j === idx); }); } });
        }, { root: sc, threshold: 0.5 });
        beats.forEach(function (b) { nio.observe(b); });
    }
    // cartes chiffres : flip vers la source
    c2.querySelectorAll('.mvp-stat[data-flip]').forEach(function (card) {
        card.addEventListener('click', function () {
            var f = card.classList.toggle('flipped');
            card.setAttribute('aria-pressed', f ? 'true' : 'false');
        });
    });
    // méthode : "Lancer Claude" — machine de transfert (les tâches partent vers Claude)
    var mcpTasks = Array.prototype.slice.call(c2.querySelectorAll('.xfer-task'));
    var mcpClaude = document.getElementById('xferClaude');
    var mcpMe = document.getElementById('mcpMe');
    var mcpFill = document.getElementById('xferFill');
    var mcpStat = document.getElementById('xferStat');
    var mcpPellet = document.getElementById('xferPellet');
    var mcpRunBtn = document.getElementById('mcpRun');
    var mcpRunTx = mcpRunBtn ? mcpRunBtn.querySelector('.mcp-run-tx') : null;
    var mcpBusy = false;
    function mcpTr(key, fallback) {
        try { return (window.__i18n && window.__i18n.t) ? window.__i18n.t(key) : fallback; } catch (e) { return fallback; }
    }
    function mcpSetBtn(state) {
        if (!mcpRunBtn) return;
        mcpRunBtn.classList.toggle('run', state === 'run');
        mcpRunBtn.disabled = (state === 'run');
        if (mcpRunTx) {
            if (state === 'run') mcpRunTx.textContent = mcpTr('deli.imm.ch2.mcp.running', 'Traitement…');
            else if (state === 'done') mcpRunTx.textContent = mcpTr('deli.imm.ch2.mcp.replay', 'Relancer');
            else mcpRunTx.textContent = mcpTr('deli.imm.ch2.mcp.run', 'Lancer Claude');
        }
    }
    function mcpFirePellet() {
        if (!mcpPellet) return;
        mcpPellet.classList.remove('go'); void mcpPellet.offsetWidth; mcpPellet.classList.add('go');
    }
    function mcpReset() {
        mcpTasks.forEach(function (t) { t.classList.remove('in', 'scan'); });
        if (mcpClaude) mcpClaude.classList.remove('active');
        if (mcpMe) mcpMe.classList.remove('lit');
        if (mcpFill) mcpFill.style.width = '0';
        if (mcpStat) mcpStat.textContent = mcpTr('deli.imm.ch2.mcp.idle', 'en veille');
    }
    function mcpPlay() {
        if (mcpBusy) return;
        mcpReset();
        if (reduced) {
            mcpTasks.forEach(function (t) { t.classList.add('in'); });
            if (mcpFill) mcpFill.style.width = '100%';
            if (mcpMe) mcpMe.classList.add('lit');
            if (mcpStat) mcpStat.textContent = mcpTr('deli.imm.ch2.mcp.done', 'terminé');
            mcpSetBtn('done');
            return;
        }
        mcpBusy = true;
        mcpSetBtn('run');
        if (mcpClaude) mcpClaude.classList.add('active');
        var step = 560, n = mcpTasks.length;
        mcpTasks.forEach(function (t, i) {
            setTimeout(function () {
                mcpFirePellet();
                setTimeout(function () {
                    t.classList.add('in', 'scan');
                    setTimeout(function () { t.classList.remove('scan'); }, 760);
                    if (mcpFill) mcpFill.style.width = Math.round((i + 1) / n * 100) + '%';
                    if (mcpStat) mcpStat.textContent = (i + 1) + '/' + n;
                }, 380);
            }, i * step);
        });
        setTimeout(function () {
            if (mcpClaude) mcpClaude.classList.remove('active');
            if (mcpMe) mcpMe.classList.add('lit');
            if (mcpStat) mcpStat.textContent = mcpTr('deli.imm.ch2.mcp.done', 'terminé');
            mcpSetBtn('done');
            mcpBusy = false;
        }, n * step + 500);
    }
    if (mcpRunBtn) mcpRunBtn.addEventListener('click', mcpPlay);
    // galerie : lightbox
    var lb = document.getElementById('mvpLb'), lbImg = document.getElementById('mvpLbImg'),
        lbCap = document.getElementById('mvpLbCap'), lbClose = document.getElementById('mvpLbClose');
    function lbCloseFn() { if (lb) lb.hidden = true; }
    c2.querySelectorAll('.mvp-gallery figure').forEach(function (fig) {
        fig.tabIndex = 0; fig.setAttribute('role', 'button');
        var openLb = function () {
            if (!lb) return;
            var img = fig.querySelector('img'), cap = fig.querySelector('figcaption');
            lbImg.src = img.currentSrc || img.src; lbImg.alt = cap ? cap.textContent : '';
            lbCap.textContent = cap ? cap.textContent : '';
            lb.hidden = false; if (lbClose) lbClose.focus();
        };
        fig.addEventListener('click', openLb);
        fig.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openLb(); } });
    });
    if (lbClose) lbClose.addEventListener('click', lbCloseFn);
    if (lb) lb.addEventListener('click', function (e) { if (e.target === lb) lbCloseFn(); });

    window.__ch2 = { open: open, close: close };
})();

/* ---- Concept B : démo guidée "dans le produit" ---- */
(function () {
    var d = document.getElementById('immDemo');
    if (!d) return;
    var sc = document.getElementById('demoScroll'),
        prog = document.getElementById('demoProgress'),
        exit = document.getElementById('demoExit'),
        pathEl = document.getElementById('demoPath');
    var shots = Array.prototype.slice.call(d.querySelectorAll('.demo-shot'));
    var steps = Array.prototype.slice.call(d.querySelectorAll('.demo-step'));
    function setActive(step) {
        steps.forEach(function (s) { s.classList.toggle('active', s === step); });
        var n = +step.dataset.step;
        if (n >= 0) {
            shots.forEach(function (im) { im.classList.toggle('on', +im.dataset.step === n); });
            if (pathEl && step.dataset.path) pathEl.textContent = step.dataset.path;
        }
    }
    function onProg() { if (!prog) return; var m = sc.scrollHeight - sc.clientHeight; prog.style.transform = 'scaleX(' + (m > 0 ? sc.scrollTop / m : 0) + ')'; }
    sc.addEventListener('scroll', onProg, { passive: true });
    var io;
    function open() {
        d.hidden = false; document.body.style.overflow = 'hidden'; sc.scrollTop = 0; onProg();
        if (steps[0]) setActive(steps[0]);
        if (io) io.disconnect();
        io = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) setActive(en.target); }); }, { root: sc, threshold: 0.55 });
        steps.forEach(function (s) { io.observe(s); });
        if (exit) exit.focus();
    }
    function close() { d.hidden = true; document.body.style.overflow = ''; if (io) io.disconnect(); }
    if (exit) exit.addEventListener('click', close);
    document.addEventListener('keydown', function (e) { if (!d.hidden && e.key === 'Escape') { e.preventDefault(); close(); } });
    window.__demo = { open: open, close: close };
})();

/* === Système : explorateur de tokens (données réelles Figma DS v2) === */
(function () {
    var root = document.getElementById('tkx');
    if (!root) return;
    function tr(k, f) { try { return (window.__i18n && window.__i18n.t) ? window.__i18n.t(k) : f; } catch (e) { return f; } }
    var PRIM = [
        { n: 'brand', h: '#183115' }, { n: 'teal', h: '#00806a' }, { n: 'yellow', h: '#f1dc5f' }, { n: 'lime', h: '#c8e4a4' },
        { n: 'litchi', h: '#f4efe4' }, { n: 'base', h: '#fefefe' }, { n: 'blue', h: '#2968c6' }, { n: 'bordeaux', h: '#750638' },
        { n: 'forest', h: '#2a4a25' }, { n: 'sage', h: '#4d6b45' }, { n: 'dark-bg', h: '#132613' }, { n: 'dark-200', h: '#1c331c' },
        { n: 'dark-300', h: '#264226' }, { n: 'teal-bright', h: '#2dd4a8' }, { n: 'lime-bright', h: '#a3d977' }, { n: 'blue-bright', h: '#6ba4e8' },
        { n: 'bordeaux-bright', h: '#d46a6a' }, { n: 'yellow-dark', h: '#f0d264' }, { n: 'litchi-inv', h: '#e8e6e1' }, { n: 'white', h: '#ffffff' }, { n: 'black', h: '#000000' }
    ];
    function V(n, l, d) { return { n: n, v: '--color-' + n.replace('/', '-'), l: l, d: d }; }
    var SEM = [
        { g: 'Surface', t: [V('surface/base-100', '#fefefe', '#272727'), V('surface/base-200', '#f5f4f0', '#1c331c'), V('surface/base-300', '#f4efe4', '#264226'), V('surface/neutral', '#183115', '#183115'), V('surface/neutral-hover', '#2a4a25', '#2a4a25')] },
        { g: 'Primary / Secondary / Accent', t: [V('primary/default', '#00806a', '#2dd4a8'), V('primary/content', '#ffffff', '#0d2818'), V('primary/hover', '#007462', '#23b896'), V('secondary/default', '#c8e4a4', '#a3d977'), V('secondary/content', '#183115', '#0d2818'), V('accent/default', '#f1dc5f', '#f0d264'), V('accent/content', '#183115', '#0d2818')] },
        { g: 'Info / Warning / Error / Success', t: [V('info/default', '#2968c6', '#6ba4e8'), V('info/bg', '#2968c61a', '#6ba4e826'), V('info/content', '#ffffff', '#0d2818'), V('warning/default', '#ff723b', '#ff723b'), V('warning/bg', '#ffe3d6', '#3a1f12'), V('warning/content', '#750638', '#ffffff'), V('error/default', '#750638', '#d46a6a'), V('error/bg', '#7506381a', '#d46a6a26'), V('error/content', '#e2b94a', '#efefef'), V('error/on-dark', '#f4a8a8', '#f4a8a8'), V('success/default', '#f3effe', '#7242ff'), V('success/content', '#7242ff', '#f3effe')] },
        { g: 'Muted / Text', t: [V('muted/bg', '#18311512', '#e8e6e114'), V('muted/content', '#183115a6', '#e8e6e1a6'), V('text/default', '#183115', '#e8e6e1'), V('text/muted', '#183115a6', '#e8e6e1c7'), V('text/subtle', '#183115bf', '#e8e6e1e0'), V('text/faint', '#18311580', '#e8e6e19e'), V('text/on-dark', '#ffffffd9', '#ffffffd9'), V('text/on-dark-muted', '#ffffff8c', '#ffffff8c')] },
        { g: 'Border / Tint', t: [V('border/default', '#1831151a', '#e8e6e11f'), V('border/input', '#18311526', '#e8e6e12e'), V('border/light', '#ffffff1f', '#ffffff1a'), V('tint/1', '#1831150a', '#e8e6e10a'), V('tint/2', '#18311514', '#e8e6e114'), V('tint/3', '#18311526', '#e8e6e126'), V('tint/4', '#18311540', '#e8e6e140')] },
        { g: 'State / Row', t: [V('state/locked-bg', '#fff5f5', '#d46a6a1a'), V('state/locked-border', '#ef444433', '#d46a6a4d'), V('state/modif-bg', '#f0fdf4', '#a3d97714'), V('state/modif-border', '#a3e6a0', '#a3d97759'), V('state/day-delivery-bg', '#eff6ff', '#6ba4e80f'), V('state/day-delivery-border', '#bfdbfe', '#6ba4e838'), V('row/zebra', '#f9faf8', '#ffffff0a')] },
        { g: 'Chart', t: [V('chart/green', '#1eb87a', '#34d399'), V('chart/yellow', '#e2b94a', '#fbbf24'), V('chart/blue', '#3b82f6', '#60a5fa'), V('chart/orange', '#f59e0b', '#fb923c'), V('chart/purple', '#a78bfa', '#c4b5fd'), V('chart/bee', '#fbbf24', '#fcd34d')] }
    ];
    var primWrap = document.getElementById('tkxPrim');
    var semWrap = document.getElementById('tkxSem');
    var readEl = document.getElementById('tkxRead');
    var mode = 'light';

    PRIM.forEach(function (p) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'tkx-sw'; b.dataset.prim = '1'; b.dataset.name = p.n; b.dataset.hex = p.h;
        b.innerHTML = '<i style="background:' + p.h + '"></i><b>' + p.n + '</b><em>' + p.h.toUpperCase() + '</em>';
        primWrap.appendChild(b);
    });
    SEM.forEach(function (grp) {
        var box = document.createElement('div'); box.className = 'tkx-sem-group';
        var lab = document.createElement('p'); lab.className = 'tkx-sgl'; lab.textContent = grp.g; box.appendChild(lab);
        var grid = document.createElement('div'); grid.className = 'tkx-grid';
        grp.t.forEach(function (tk) {
            var b = document.createElement('button');
            b.type = 'button'; b.className = 'tkx-sw'; b.dataset.name = tk.n; b.dataset.var = tk.v; b.dataset.l = tk.l; b.dataset.d = tk.d;
            b.innerHTML = '<i style="background:var(' + tk.v + ')"></i><b>' + tk.n + '</b><em></em>';
            grid.appendChild(b);
        });
        box.appendChild(grid); semWrap.appendChild(box);
    });

    function aliasOf(val) {
        var v = val.toLowerCase();
        if (v.length === 9) return tr('deli.imm.ch2.tok.overlay', 'overlay rgba');
        for (var i = 0; i < PRIM.length; i++) { if (PRIM[i].h.toLowerCase() === v) return tr('deli.imm.ch2.tok.alias', 'aliasé →') + ' ' + PRIM[i].n; }
        return tr('deli.imm.ch2.tok.raw', 'valeur brute');
    }
    function hint() { if (readEl) readEl.textContent = tr('deli.imm.ch2.tok.hint', 'Survole un token : valeur + aliasing'); }
    function applyMode(m) {
        mode = m; root.dataset.mode = m;
        SEM.forEach(function (grp) {
            grp.t.forEach(function (tk) { root.style.setProperty(tk.v, m === 'dark' ? tk.d : tk.l); });
        });
        Array.prototype.forEach.call(semWrap.querySelectorAll('.tkx-sw'), function (b) {
            b.querySelector('em').textContent = (m === 'dark' ? b.dataset.d : b.dataset.l).toUpperCase();
        });
        Array.prototype.forEach.call(root.querySelectorAll('.tkx-seg-b'), function (sb) {
            var on = sb.dataset.mode === m; sb.classList.toggle('on', on); sb.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        hint();
    }
    function show(b) {
        if (!readEl || !b) return;
        if (b.dataset.prim) { readEl.textContent = b.dataset.name + ' · ' + b.dataset.hex.toUpperCase() + ' · primitive'; return; }
        var val = (mode === 'dark' ? b.dataset.d : b.dataset.l);
        readEl.textContent = b.dataset.name + ' · ' + val.toUpperCase() + ' · ' + aliasOf(val);
    }
    root.addEventListener('mouseover', function (e) { var b = e.target.closest('.tkx-sw'); if (b) show(b); });
    root.addEventListener('focusin', function (e) { var b = e.target.closest('.tkx-sw'); if (b) show(b); });
    root.addEventListener('click', function (e) {
        var seg = e.target.closest('.tkx-seg-b'); if (seg) { applyMode(seg.dataset.mode); return; }
        var b = e.target.closest('.tkx-sw'); if (b) show(b);
    });
    applyMode('light');
})();

/* === Produit : écran annoté (hotspots → décisions issues du test) === */
(function () {
    var fig = document.getElementById('shotx');
    if (!fig) return;
    var pop = document.getElementById('hxPop');
    function tr(k, f) { try { return (window.__i18n && window.__i18n.t) ? window.__i18n.t(k) : f; } catch (e) { return f; } }
    var dots = Array.prototype.slice.call(fig.querySelectorAll('.hx-dot'));
    function hint() { pop.innerHTML = '<span class="hx-hint">' + tr('deli.imm.ch2.prod.hxhint', "Survole un point pour explorer l'écran.") + '</span>'; }
    function render(d) {
        var n = d.dataset.hx, pri = d.dataset.pri || '';
        var feat = pri !== 'P1' ? ' feat' : '';
        var h = tr('deli.imm.ch2.prod.hx' + n + '.h', '');
        var b = tr('deli.imm.ch2.prod.hx' + n + '.b', '');
        pop.innerHTML = '<p class="hx-h"><span class="hx-pri' + feat + '">' + pri + '</span>' + h + '</p><p class="hx-b">' + b + '</p>';
    }
    dots.forEach(function (d) {
        d.setAttribute('aria-label', tr('deli.imm.ch2.prod.hx' + d.dataset.hx + '.h', 'Point ' + d.dataset.hx));
        function act() { dots.forEach(function (x) { x.classList.remove('on'); }); d.classList.add('on'); render(d); }
        d.addEventListener('mouseover', act);
        d.addEventListener('focus', act);
        d.addEventListener('click', act);
    });
    fig.addEventListener('mouseleave', function () { dots.forEach(function (x) { x.classList.remove('on'); }); hint(); });
})();

/* ---- Chapitre CX Copilot (scrollytelling autonome) ---- */
(function () {
    var c3 = document.getElementById('immChapter3');
    if (!c3) return;
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var sc = document.getElementById('chap3Scroll'),
        nav = document.getElementById('chap3Nav'),
        prog = document.getElementById('chap3Progress'),
        exit = document.getElementById('chap3Exit'),
        cta = document.getElementById('chap3Cta');
    var rev = Array.prototype.slice.call(c3.querySelectorAll('.r'));
    function tr(k, f) { try { return (window.__i18n && window.__i18n.t) ? window.__i18n.t(k) : f; } catch (e) { return f; } }
    function countUp(el) {
        if (el._done) return; el._done = true;
        var target = +el.dataset.count, pre = el.dataset.prefix || '', suf = el.dataset.suffix || '', t0 = null, dur = 1100;
        if (reduced) { el.textContent = pre + target + suf; return; }
        function step(ts) { if (!t0) t0 = ts; var p = Math.min((ts - t0) / dur, 1); el.textContent = pre + Math.round(target * (1 - Math.pow(1 - p, 3))) + suf; if (p < 1) requestAnimationFrame(step); }
        requestAnimationFrame(step);
    }
    function onProg() { if (prog && sc) prog.style.transform = 'scaleX(' + (sc.scrollTop / Math.max(1, sc.scrollHeight - sc.clientHeight)) + ')'; }
    sc.addEventListener('scroll', function () { onProg(); }, { passive: true });

    /* widget : workflow */
    var cxw = document.getElementById('cxw');
    var cxwRun = document.getElementById('cxwRun'), cxwOut = document.getElementById('cxwOut');
    var cxwReply = document.getElementById('cxwReply'), cxwSend = document.getElementById('cxwSend'), cxwDone = document.getElementById('cxwDone');
    var cxwPlayed = false;
    function cxwReset() {
        cxwPlayed = false;
        if (cxwOut) { cxwOut.hidden = true; cxwOut.classList.remove('show'); }
        if (cxwDone) cxwDone.hidden = true;
        if (cxw) cxw.querySelectorAll('.cxw-kw').forEach(function (b) { b.classList.remove('on'); });
        if (cxwReply) cxwReply.textContent = tr('deli.imm.ch3.wf.r0', cxwReply.textContent);
    }
    function cxwPlay() {
        if (cxwPlayed || !cxwOut) return; cxwPlayed = true;
        cxwOut.hidden = false;
        if (reduced) { cxwOut.classList.add('show'); return; }
        requestAnimationFrame(function () { cxwOut.classList.add('show'); });
    }
    if (cxwRun) cxwRun.addEventListener('click', cxwPlay);
    if (cxw) cxw.querySelectorAll('.cxw-kw').forEach(function (b) {
        b.addEventListener('click', function () {
            cxw.querySelectorAll('.cxw-kw').forEach(function (x) { x.classList.remove('on'); });
            b.classList.add('on');
            var wrap = cxwReply.parentElement;
            var key = b.dataset.kw === 'esc' ? 'deli.imm.ch3.wf.resc' : 'deli.imm.ch3.wf.rferme';
            var fb = b.dataset.kw === 'esc'
                ? '« Bonjour, votre dossier est escaladé à Stéphane (responsable). Machine de secours vendredi matin, suivi personnalisé jusqu\u2019à résolution complète. »'
                : '« Bonjour, nous prenons la pleine mesure de l\u2019incident. Machine de secours livrée vendredi matin, réparation engagée en parallèle, et un geste commercial vous sera proposé. »';
            if (reduced) { cxwReply.textContent = tr(key, fb); return; }
            wrap.classList.add('regen');
            setTimeout(function () { cxwReply.textContent = tr(key, fb); wrap.classList.remove('regen'); }, 260);
        });
    });
    if (cxwSend) cxwSend.addEventListener('click', function () { if (cxwDone) cxwDone.hidden = false; });

    /* widget : business case (toggle scénario) */
    var cxr = document.getElementById('cxr');
    function cxrApply(mode) {
        if (!cxr) return;
        cxr.dataset.mode = mode;
        cxr.querySelectorAll('b[data-cons]').forEach(function (b) {
            var v = mode === 'opt' ? b.dataset.opt : b.dataset.cons;
            b.textContent = (b.dataset.prefix || '') + v + ' K€';
        });
        cxr.querySelectorAll('.cxr-seg-b').forEach(function (sb) {
            var on = sb.dataset.mode === mode; sb.classList.toggle('on', on); sb.setAttribute('aria-selected', on ? 'true' : 'false');
        });
    }
    if (cxr) cxr.querySelectorAll('.cxr-seg-b').forEach(function (sb) {
        sb.addEventListener('click', function () { cxrApply(sb.dataset.mode); });
    });

    /* galerie écrans → lightbox (réutilise #mvpLb) */
    var lb = document.getElementById('mvpLb'), lbImg = document.getElementById('mvpLbImg'), lbCap = document.getElementById('mvpLbCap');
    c3.querySelectorAll('.cx3-shot').forEach(function (fig) {
        fig.tabIndex = 0; fig.setAttribute('role', 'button');
        function openLb() {
            if (!lb) return;
            var img = fig.querySelector('img'), cap = fig.querySelector('figcaption');
            lbImg.src = img.currentSrc || img.src; lbImg.alt = cap ? cap.textContent : '';
            if (lbCap) lbCap.textContent = cap ? cap.textContent : '';
            lb.hidden = false;
        }
        fig.addEventListener('click', openLb);
        fig.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openLb(); } });
    });

    var io;
    function open() {
        c3.hidden = false; document.body.style.overflow = 'hidden'; sc.scrollTop = 0; onProg();
        rev.forEach(function (el) { el.classList.remove('in'); });
        c3.querySelectorAll('[data-count]').forEach(function (el) { el._done = false; el.textContent = '0'; });
        cxwReset(); cxrApply('cons');
        if (io) io.disconnect();
        if (reduced) {
            rev.forEach(function (el) { el.classList.add('in'); });
            c3.querySelectorAll('[data-count]').forEach(countUp);
            cxwPlay();
        } else {
            io = new IntersectionObserver(function (es) {
                es.forEach(function (en) {
                    if (en.isIntersecting) {
                        en.target.classList.add('in');
                        if (en.target.querySelectorAll) en.target.querySelectorAll('[data-count]').forEach(countUp);
                        if (en.target.id === 'cxw' || (en.target.querySelector && en.target.querySelector('#cxw'))) cxwPlay();
                        io.unobserve(en.target);
                    }
                });
            }, { root: sc, threshold: 0.25 });
            rev.forEach(function (el) { io.observe(el); });
        }
        if (exit) exit.focus();
    }
    function close() { c3.hidden = true; document.body.style.overflow = ''; if (io) io.disconnect(); }
    if (exit) exit.addEventListener('click', close);
    if (cta) cta.addEventListener('click', close);
    document.addEventListener('keydown', function (e) {
        if (c3.hidden || e.key !== 'Escape') return;
        e.preventDefault();
        if (lb && !lb.hidden) { lb.hidden = true; } else { close(); }
    });
    var beats = Array.prototype.slice.call(c3.querySelectorAll('.chap-beat'));
    if (nav && beats.length) {
        beats.forEach(function (b, i) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.innerHTML = '<span class="lbl">' + (b.dataset.nav || (i + 1)) + '</span><span class="dotn"></span>';
            btn.setAttribute('aria-label', b.dataset.nav || ('Section ' + (i + 1)));
            btn.addEventListener('click', function () { b.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth' }); });
            nav.appendChild(btn);
        });
        var navBtns = nav.querySelectorAll('button');
        var nio = new IntersectionObserver(function (es) {
            es.forEach(function (en) { if (en.isIntersecting) { var idx = beats.indexOf(en.target); navBtns.forEach(function (x, j) { x.classList.toggle('on', j === idx); }); } });
        }, { root: sc, threshold: 0.5 });
        beats.forEach(function (b) { nio.observe(b); });
    }
    window.__ch3 = { open: open, close: close };
})();
